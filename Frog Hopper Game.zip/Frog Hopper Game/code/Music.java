import java.io.*;
import java.net.*;
import java.applet.Applet;
import java.applet.AudioClip;
/**
 * Music Class
 * all music sources for the whole game
 * Paths of all soundtracks and methods of playing them are involved
 * @author
 */
public class Music
{
    private File bgmPath;
    private File beforeClickPath;
    private File clickedPath;
    private File winPath;
    private File losePath;
    private File frogPath;
    private File jumpPath;
    private AudioClip bgm;
    private AudioClip beforeClick;
    private AudioClip clicked;
    private AudioClip win;
    private AudioClip lose;
    private AudioClip frog;
    private AudioClip jump;
    private boolean bgmOn = false;
    private boolean haveStoped = false;

    /**
     * Music constructor
     * This method provides all paths of music in need
     */
    public Music()
    {
        bgmPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\Bgm.wav");
        beforeClickPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\beforeClick.wav");
        winPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\win.wav");
        losePath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\lose.wav");
        frogPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\frog.wav");
        jumpPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\jump.wav");
        clickedPath = new File("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\clicked.wav");
    }

    /**
     * playBGM method
     * used to play the background music
     * looping until the player exits
     */
    public void playBGM(){
        if(bgmOn){
        }
        else if(haveStoped){
        }
        else{
            File file = bgmPath;
            try {
                URL url = bgmPath.toURL();
                bgm = Applet.newAudioClip(url);  
                bgmOn = true;
                bgm.loop();
            } 
            catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * getIsPlay method
     * @return boolean which indicates whether the BGM is on or not
     */
    public boolean getIsPlay(){
        return bgmOn;
    }
    
    /**
     * setHaveStoped method
     * used to change the state of the BGM 
     * @param isOn true or false
     */
    public void setHaveStoped(boolean isOn){
        this.haveStoped = isOn;
    }
    
    /**
     * getHaveStoped method
     * @return boolean which indicates whether the BGM has been stoped or not
     */
    public boolean getHaveStoped(){
        return haveStoped;
    }
    
    /**
     * stopBGM method
     * used to turn off the background music
     * pass the parameter to the class indicating that the BGM has been stoped
     */
    public void stopBGM(){
        bgm.stop();
        bgmOn = false;
        haveStoped = true;
    }
    
    /**
     * playBeforeClick method
     * used to play the sound when the mouse touches the button each time
     */
    public void playBeforeClick(){
        File file = beforeClickPath;
        try {
            URL url = beforeClickPath.toURL();
            beforeClick = Applet.newAudioClip(url);
            beforeClick.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * playClicked method
     * used to play the sound when the mouse clickes the button each time
     */
    public void playClicked(){
        File file = clickedPath;
        try {
            URL url = clickedPath.toURL();
            clicked = Applet.newAudioClip(url);
            clicked.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * playWin method
     * used to play the sound when the player completes one level of the game
     */
    public void playWin(){
        File file = winPath;
        try {
            URL url = winPath.toURL();
            win = Applet.newAudioClip(url);
            win.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * playLose method
     * used to play the sound when the player lose the game
     */
    public void playLose(){
        File file = losePath;
        try {
            URL url = losePath.toURL();
            lose = Applet.newAudioClip(url);
            lose.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * playFrog method
     * used to play the sound when the frog has been clicked
     */
    public void playFrog(){
        File file = frogPath;
        try {
            URL url = frogPath.toURL();
            frog = Applet.newAudioClip(url);
            frog.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * playJump method
     * used to play the sound when the frog has been eliminated
     */
    public void playJump(){
        File file = jumpPath;
        try {
            URL url = jumpPath.toURL();
            jump = Applet.newAudioClip(url);
            jump.play();
        } 
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}
