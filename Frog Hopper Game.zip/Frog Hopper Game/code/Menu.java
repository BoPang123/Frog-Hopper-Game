import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * Menu class
 * Menu for game called Froggy
 * background music is provided to give a better experience of playing
 * Players can choose the level they want to start the game by clicking the 'start' clickable button
 * and get knowledge of how to play this game by clicking the 'help' clickable button
 * and set the background music by clicking the 'setting' clickable button
 * and exit the game by clicking the 'exit' clickable button
 * @author
 */
public class Menu implements ActionListener, MouseListener{
    private JFrame frame;
    private Board game;
    private JButton help;
    private JButton exit;
    private JButton start;
    private JButton setting;
    private JLabel background;
    static private Music music = new Music();
    private Object[] settingOptions = new Object[]{"Music On", "Music Off"};
    private ImageIcon backgroundImage = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\cover.png");
    private ImageIcon settingImage = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\music.jpg");
    
    /**
     * Menu constructor
     * This method returns frame containing
     * start, setting, help, and exit buttons in the center
     * an image as background
     */
    public Menu(){
        //Initialize menu window
        frame = new JFrame();
        frame.setTitle("Hoppers!");
        frame.setSize(750, 750);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        background = new JLabel(backgroundImage);
        background.setSize(750, 750);
        frame.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
        JPanel panel = (JPanel) frame.getContentPane();
        
        //Initialize basic panel and layout of the menu window
        BoxLayout layout= new BoxLayout(panel, BoxLayout.X_AXIS);
        panel.setLayout(layout);
        
        //Initialize the button panel and layout of the menu
        JPanel mainPanel = new JPanel();
        BoxLayout menuLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
        mainPanel.setLayout(menuLayout);
        
        //Initialize menu buttons and then add them to the panel in the proper location
        start = new JButton("Start");
        start.addMouseListener(this);
        setting = new JButton("Music");
        setting.addMouseListener(this);
        help = new JButton(" Help");
        help.addMouseListener(this);
        exit = new JButton(" Exit");
        exit.addMouseListener(this);
        mainPanel.add(Box.createGlue());
        mainPanel.add(Box.createGlue());
        mainPanel.add(start);
        start.addActionListener(this);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(setting);
        setting.addActionListener(this);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(help);
        help.addActionListener(this);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(exit);
        exit.addActionListener(this);
        mainPanel.add(Box.createGlue());
        
        //Set the location of menu in the whole window
        panel.add(Box.createGlue());
        panel.add(mainPanel);
        panel.add(Box.createHorizontalStrut(10));
        
        //Make the menu visible
        panel.setOpaque(false);
        mainPanel.setOpaque(false);
        frame.setContentPane(panel);
        frame.setVisible(true);
        
        //Play the background music as the menu appears
        music.playBGM();
    }
    
    /**
     * actionPerformed method
     * This method used to react after the player clicked
     * 'start' button, moving to the level-choosing window
     * 'help' button, showing the general way of how to play this game
     * 'setting' button, turning the music on or off
     * 'exit' button, quitting the game
     * A specific sound is also provided as response
     * @param e the event indicating that the button has been clicked
     */
    public void actionPerformed(ActionEvent e){
        //Click the exit button
        if(e.getSource() == exit){
            music.playClicked();
            System.exit(0); // exit the game
        }
        //Click the help button
        if(e.getSource() == help){
            music.playClicked();
            //Show the player how to play the game
            JOptionPane.showMessageDialog(null, "GOAL:\n" + 
            "Eliminate all green frogs from the board and make sure that red frog is the only frog on the board. \n"
            + "\n"+ "INSTRUCTION:\n" + "Click on the frog and the lotus leaf to determine the moving target and landing point .\n"
            + "Frogs can jump horizontally, vertically or diagonally, but may only be moved onto a pad .\n"
            + "The target frog (red one) needs to jump over another frog to move .\n", "HELP", JOptionPane.PLAIN_MESSAGE);
        }
        // Click the start button
        if(e.getSource() == start){
            music.playClicked();
            frame.dispose();
            ChooseLevel chooseLevel = new ChooseLevel(); // move to the level-choosing interface
        }
        // Click the setting button
        if(e.getSource() == setting){
            music.playClicked();
            
            int optionSelected = JOptionPane.showOptionDialog(frame, "Play background music or not?", "SETTING", 
            JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE, settingImage, settingOptions, settingOptions[0]);
            //Choose "Music On", turn on the music
            if(optionSelected == JOptionPane.YES_OPTION){
                if((!music.getIsPlay()) || (!music.getHaveStoped())){
                    music.setHaveStoped(false);
                    music.playBGM();
                }
            }
            //Choose "Music Off", turn off the music
            if(optionSelected == JOptionPane.NO_OPTION){
                music.stopBGM();
            }
        }
    }
    
    /**
     * mouseEntered method
     * This method used to react when the mouse touches the buttons
     * a specific sound will be played
     * @param e the event indicating that the button has been touched by mouse
     */
    public void mouseEntered(MouseEvent e){
        if((e.getSource() == start) || (e.getSource() == setting) 
        || (e.getSource() == help) || (e.getSource() == exit)){
            music.playBeforeClick();
        }
    }
    
    /**
     * mouseClicked method
     * is an abstract funtion
     */
    public void mouseClicked(MouseEvent e){}
    
    /**
     * mouseExited method
     * is an abstract funtion
     */
    public void mouseExited(MouseEvent e){}
    
    /**
     * mousePressed method
     * is an abstract funtion
     */
    public void mousePressed(MouseEvent e){}
    
    /**
     * mouseReleased method
     * is an abstract funtion
     */
    public void mouseReleased(MouseEvent e){}
    
    }

