import javax.swing.*;
/**
 * Square class 
 * is 1 of 25 buttons in Froggy game map, displaying an image which has also a description
 * Square also holds its own x and y coordinate which can be from 0 to 5
 * @author 
 */
public class Square
{
    private ImageIcon image;
    private JButton button;
    private int x;
    private int y;

    /**
     * Square constructor
     * @param which image id from 0 to 5 which should be displayed
     * 0 creates water
     * 1 creates pad
     * 2 creates greenFrog
     * 3 creates yellow_greenFrog
     * 4 creates redFrog
     * 5 creates yellow_redFrog
     * @param x x coordinate on 5x5 map
     * @param y y corrdinate on 5x5 map
     */
    public Square(int which, int x, int y)
    {
        //Determine which icon should be used
        if(which == 0){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\Water.png", "0");
        }
        if(which == 1){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\LilyPad.png", "1");
        }
        if(which == 2){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\GreenFrog.png", "2");
        }
        if(which == 3){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\GreenFrog2.png", "3");
        }
        if(which == 4){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\RedFrog.png", "4");
        }
        if(which == 5){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\RedFrog2.png", "5");
        }
        
        //Display the icon as button
        button = new JButton(image);
        button.setIcon(image);
        
        //Set the location of the button on 5x5 map
        this.x = x;
        this.y = y;
    }

    /**
     * getButton method
     * @return JButton from Square
     */
    public JButton getButton(){
        return button;
    }
    
    /**
     * getX method
     * @return int which is x coordinate of this Square
     */
    public int getX(){
        return x;
    }
    
    /**
     * getY method
     * @return int which is y coordinate of this Square
     */
    public int getY(){
        return y;
    }
    
    /**
     * setX method
     * used to change x coordinate of this Square
     * @param x not negative integer value lower than 5
     */
    public void setX(int x){
        this.x = x;
    }
    
    /**
     * setY method
     * used to change y coordinate of this Square
     * @param y not negative integer value lower than 5
     */
    public void setY(int y){
        this.y = y;
    }
    
    /**
     * getDescription method
     * @return int integer from 1 to 5 which is the id of image shown
     */
    public int getDescription(){
        return Integer.parseInt(image.getDescription());
    }
    
    /**
     * setDescription method
     * used to change description of a image from Square
     * @param description not negative integer value lower than 6
     */
    public void setDescription(int description){
        image.setDescription(Integer.toString(description));
    }
    
    /**
     * setSquare method
     * used to change image and its description of this Square
     * @param which not negative integer value lower than 5
     * 0 creates pad 
     * and change the description into 1
     * 1 creates greenFrog 
     * and change the description into 2
     * 2 creates yellow_greenFrog 
     * and change the description into 3
     * 3 creates redFrog 
     * and change the description into 4
     * 4 creates yellow_redFrog 
     * and change the description into 5
     */
    public void setButtonIcon(int which){
        if(which == 0){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\LilyPad.png", "1");
        }
        if(which == 1){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\GreenFrog.png", "2");
        }
        if(which == 2){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\GreenFrog2.png", "3");
        }
        if(which == 3){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\RedFrog.png", "4");
        }
        if(which == 4){
            image = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\RedFrog2.png", "5");
        }
        
        //Change the image and display
        button.setIcon(image);
    }
    
    /**
     * moveTo method
     * used to move the frog to the clicked location
     * and then eliminate the frog between the former and clicked locations
     * @param newSquare the location that the frog should move to
     */
    public void moveTo(Square newSquare){
        //The situation of green frog
        if(this.getDescription() == 2 || this.getDescription() == 3){
            if(newSquare.getDescription() == 1){ // the clicked location has a pad
                if(((Math.abs(newSquare.getY() - this.getY()) == 2) && (Math.abs(newSquare.getX() - this.getX()) == 2)) ||
                ((Math.abs(newSquare.getY() - this.getY()) == 4) && (Math.abs(newSquare.getX() - this.getX()) == 0)) ||
                ((Math.abs(newSquare.getY() - this.getY()) == 0) && (Math.abs(newSquare.getX() - this.getX()) == 4))){                    
                    newSquare.setButtonIcon(1); // the clicked location becomes a green frog
                    this.setButtonIcon(0); // former location becomes the pad
                }
            }
        }
        
        //The situation of red frog
        if(this.getDescription() == 4 || this.getDescription() == 5){
            if(newSquare.getDescription() == 1){ // the clicked location has a pad
                if((Math.abs(newSquare.getY() - this.getY()) == 2) && ((Math.abs(newSquare.getX() - this.getX()) == 2)) ||
                ((Math.abs(newSquare.getY() - this.getY()) == 4) && (Math.abs(newSquare.getX() - this.getX()) == 0)) ||
                ((Math.abs(newSquare.getY() - this.getY()) == 0) && (Math.abs(newSquare.getX() - this.getX()) == 4))){                    
                    newSquare.setButtonIcon(3); // the clicked location becomes a red frog
                    this.setButtonIcon(0); // former location becomes the pad
                }
            }
        }
    }
    
}
