import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * Board class
 * Contains 750x750p frame
 * from which 700x750 should go for 2D Square array called map
 * Board also has JButton 'buttonClick' to store currently clicked button
 * Current level is stored as integer called currentLevel
 * At the top of frame there are 
 * 'giveUp' clickable button if player want to give up and go back to menu
 * 'tryAgain' clickable button if player want to try completing same level again
 * 'setLevel' clickable button if player want to adjust the level of game
 * 'help' clickable button if player want to know how to play this game
 
 * need to change the path in four classes: Board, Square, ChooseLevel and Music.
 */
public class Board implements ActionListener, MouseListener
{
    private JFrame frame;
    Square[][] map = new Square[5][5];
    private Square buttonClick;
    private JButton giveUp;
    private JButton tryAgain;
    private JButton help;
    private JButton setLevel;
    private int currentLevel;
    private int lasti = 0;
    private int lastj = 0;
    private int note = 0; // if note =1, means the user have clicked one board
    private int haveMoved = 0;// 
    private int haveFroginMiddle = 0;//
    private int haveGreenFrog;
    private boolean haveOneCanMove = false;
    private boolean canMove = false;
    private boolean win = false;
    private boolean lose = false;
    private Music music = new Music();
    private ImageIcon victory = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\victory.png");
    private ImageIcon defeat = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\defeat.png");
    private Object[] winOptions = new Object[]{"Next Level", "Retry", "Back to Menu"};
    private Object[] loseOptions = new Object[]{"Retry", "Back to Menu"};
    private Object[] levelOptions = new Object[]{"Level 1", "Level 2", "Level 3"};

    /**
     * Board constructor (basic map)
     * This method returns frame containing
     * giveUp, tryAgain, setting, and help buttons at the top
     * 5x5 Square map in the center
     */
    public Board() 
    {
        //Set the frame ready
        frame = new JFrame();
        frame.setTitle("Hoppers!");
        frame.setSize(750, 750);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Set the main panel containing all the items
        JPanel mainPanel = new JPanel();
        BorderLayout bigLayout = new BorderLayout();
        mainPanel.setLayout(bigLayout);
        
        //Set the map into 5x5
        GridLayout mainLayout = new GridLayout(5, 5);
        JPanel panel = new JPanel();
        panel.setLayout(mainLayout);
        
        //Initialize buttonClick to water
        buttonClick = new Square(0, 1, 1);
        
        //Setting the basic map (show the image of water and pads)
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                if((i % 2 == 0 && j % 2 == 0) || (i % 2 == 1 && j % 2 == 1)){
                    map[i][j] = new Square(1, i, j);
                    map[i][j].getButton().addActionListener(this);
                    panel.add(map[i][j].getButton());
                }
                
                else{
                    map[i][j] = new Square(0, i, j);
                }
                panel.add(map[i][j].getButton());
                map[i][j].getButton().addMouseListener(this);
            }
        }
        
        //Setting the button panel containing functions of giving up, trying again, setting, and helping
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
        giveUp = new JButton("Give up?");
        giveUp.addActionListener(this);
        giveUp.addMouseListener(this);
        tryAgain = new JButton("Try again?");
        tryAgain.addActionListener(this);
        tryAgain.addMouseListener(this);
        setLevel = new JButton("Set Level");
        setLevel.addActionListener(this);
        setLevel.addMouseListener(this);
        help = new JButton("help");
        help.addActionListener(this);
        help.addMouseListener(this);
        buttonPanel.add(giveUp);
        buttonPanel.add(tryAgain);
        buttonPanel.add(setLevel);
        buttonPanel.add(help);
        
        //Setting the location of panels
        mainPanel.add("Center", panel);
        mainPanel.add("North", buttonPanel);
        frame.setContentPane(mainPanel);
        mainPanel.setOpaque(false);
        frame.setVisible(true);
    }
    
    /**
     * getLevel method
     * @return int which is the current level of the game
     */
    public int getLevel(){
        return currentLevel;
    }
    
    /**
     * setLevel method
     * used to change current level of the game
     * @param level not negative integer value from 1 to 3
     */
    public void setLevel(int level){
        this.currentLevel = level;
    }
    
    /**
     * winGame method
     * used to determine whether the player has completed the current level
     * Two conditions are needed for wining
     * the red frog remains on the map
     * and there is no green frog on the map
     * A specific music is also provided to celebrate it
     */
    public void winGame(){
        boolean haveRedFrog = false;
        int haveGreenFrog = 0;
        
        //Counting the rest number of frogs on Board
        for(int k = 0; k < 5; k++){
            for(int l = 0; l < 5; l++){
                if(map[k][l].getDescription() == 4 || map[k][l].getDescription() == 5){
                    haveRedFrog = true;
                }
                if(map[k][l].getDescription() == 2 || map[k][l].getDescription() == 3){
                    haveGreenFrog++;
                }
            }
        }
        
        //Determine the conditions of win, which are having red frog and no green frog 
        if(haveGreenFrog == 0 && haveRedFrog){
            win = true;
        }
        
        //Meet all conditions of win
        if(win){
            music.playWin();
            
            int optionSelected = JOptionPane.showOptionDialog(frame, "You have completed this level!", "CONGRATULATION", 
            JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE, victory, winOptions, winOptions[0]);
            //Choose "Next Level", move to the next level of the game
            if(optionSelected == JOptionPane.YES_OPTION){
                music.playClicked();
                currentLevel++;
                Play play = new Play(currentLevel);
                frame.dispose();
                //At the final level of the game
                if(currentLevel > 3){
                    JOptionPane.showMessageDialog(null, "Congratulation! You win!", "CONGRATULATION", JOptionPane.PLAIN_MESSAGE);
                    Menu menu = new Menu();
                }
            }
            //Choose "Retry", play the current level again
            if(optionSelected == JOptionPane.NO_OPTION){
                music.playClicked();
                frame.dispose();
                Play play = new Play(currentLevel);
            }
            //Choose "Exit", back to the menu window
            if(optionSelected == JOptionPane.CANCEL_OPTION){
                music.playClicked();
                frame.dispose();
                Menu menu = new Menu();
            }
        }
        
    }
    
    /**
     * canMove method
     * used to determine whether there is any valid move for frogs on the map
     * passing the parameter of having valid-move or not to other determinations
     */
    public void canMove(){
        haveOneCanMove = false;
        
        //Searching for frogs
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                canMove = false;
                
                if((map[i][j].getDescription() == 2) || (map[i][j].getDescription() == 3) || (map[i][j].getDescription() == 4) || (map[i][j].getDescription() == 5)){
                    //Determine wheter there is any valid move
                    for (int m = 0; m < 5; m++){
                        for (int n = 0; n < 5; n++){
                            if((map[m][n].getDescription() == 2) || (map[m][n].getDescription() == 3) || (map[m][n].getDescription() == 4) || (map[m][n].getDescription() == 5)){
                                if(((Math.abs(map[i][j].getY() - map[m][n].getY()) == 1) && (Math.abs(map[i][j].getX() - map[m][n].getX()) == 1)) ||
                                ((Math.abs(map[i][j].getY() - map[m][n].getY()) == 2) && (Math.abs(map[i][j].getX() - map[m][n].getX()) == 0)) ||
                                ((Math.abs(map[i][j].getY() - map[m][n].getY()) == 0) && (Math.abs(map[i][j].getX() - map[m][n].getX()) == 2))){
                                    canMove = true; // there is a valid move at least
                                }
                            }    
                            if(canMove == true){
                                haveOneCanMove = true; // pass the valid-move to other determinations
                            } 
                        }
                    }
                }
            }
        }
    }
    
    /**
     * loseGame method
     * used to determine whether the player has lost the game
     * Two conditions will lead to lose
     * the red frog has been eliminated
     * there is no valid move for frogs
     * A specific music is also provided to remind it
     */
    public void loseGame(){
        boolean haveRedFrog = false;
        int[] locationI=new int[5];
        int[] locationJ=new int[5];
        int count=0;
        
        //Searching for the red frog on the map
        for(int k = 0; k < 5; k++){
            for(int l = 0; l < 5; l++){
                if(map[k][l].getDescription() == 4 || map[k][l].getDescription() == 5){
                    haveRedFrog = true;
                }
            }
        }
        //Not having red frog is one of the condition of lose
        if(haveRedFrog == false){
            lose = true;
        }
        
        canMove(); // receive the result of determination of valid-move
        //Not having valid move is one of the condition of lose
        if(haveOneCanMove == false){ 
            lose = true;
        }
         //all 5 frogs in the diagonal line， can't move
         for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                
                if((map[i][j].getDescription() == 4 || map[i][j].getDescription() == 5||map[i][j].getDescription() == 2 ||map[i][j].getDescription() == 3 )&&count<5){
                    locationI[count]=i;
                    locationJ[count]=j;
                    count++;
                }
               
            }

        }
        //from northwest to southeast
        if((locationI[4]-locationI[3]==1)&&(locationI[3]-locationI[2]==1)&&(locationI[2]-locationI[1]==1)&&(locationI[1]-locationI[0]==1)&&
        (locationJ[4]-locationJ[3]==1)&&(locationJ[3]-locationJ[2]==1)&&(locationJ[2]-locationJ[1]==1)&&(locationJ[1]-locationJ[0]==1)){
            lose = true;
        }
        // from northeast to southwest
        if((locationI[4]-locationI[3]==1)&&(locationI[3]-locationI[2]==1)&&(locationI[2]-locationI[1]==1)&&(locationI[1]-locationI[0]==1)&&
        (locationJ[4]-locationJ[3]==-1)&&(locationJ[3]-locationJ[2]==-1)&&(locationJ[2]-locationJ[1]==-1)&&(locationJ[1]-locationJ[0]==-1)){
            lose = true;
        }
        
        //Meet the condition of lose
        if(lose){
            music.playLose();
            
            int optionSelected = JOptionPane.showOptionDialog(frame, "You lose the game", "SORRY", 
            JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE, defeat, loseOptions, loseOptions[0]);
            //Choose "Retry", play again this level
            if(optionSelected == JOptionPane.YES_OPTION){
                music.playClicked();
                frame.dispose();
                Play play = new Play(currentLevel);
            }
            //Choose "Exit", back to menu window
            if(optionSelected == JOptionPane.NO_OPTION){
                music.playClicked();
                frame.dispose();
                Menu menu = new Menu();
            }
        }
    }

    /**
     * actionPerformed method
     * used to contain the main operations of this game, including
     * selecting frogs, moving frogs, determinating win or lose, and clicking buttons
     * Select a frog and then highlight it
     * Move a frog to the destination by using moveTo function from Square class
     * and then eliminate the frog in the middle
     * Determinate whether the player wins or not by using winGame and loseGame function from this class
     * There are four clickable buttons as well
     * 'giveUp' button for the player to go back to the menu window
     * 'tryAgain" button for the player to play the current level again
     * 'setLevel' button for the player to change into the wanted level
     * 'help' button for the player to get knowledge of how to complete the current level
     * Specific sounds are also provided as responses for each operation
     * @param e the event indicating that the button has been clicked
     */
    public void actionPerformed(ActionEvent e){
        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                //Determine whether there is any frog between selected frog and destination
                if(e.getSource() == map[i][j].getButton()){
                    if(((i - lasti == 2) && (j - lastj == 2) && (map[i-1][j-1].getDescription() == 2 || map[i-1][j-1].getDescription() == 4)) ||
                    ((i - lasti == -2) && (j - lastj == 2) && (map[i+1][j-1].getDescription() == 2 || map[i+1][j-1].getDescription() == 4)) ||
                    ((j - lastj == -2) && (i - lasti == 2) && (map[i-1][j+1].getDescription() == 2 || map[i-1][j+1].getDescription() == 4)) ||
                    ((j - lastj == -2) && (i - lasti == -2) && (map[i+1][j+1].getDescription() == 2 || map[i+1][j+1].getDescription() == 4)) ||
                    ((i == lasti) && (j - lastj == 4) && (map[i][j-2].getDescription() == 2 || map[i][j-2].getDescription() == 4)) ||
                    ((i == lasti) && (j - lastj == -4) && (map[i][j+2].getDescription() == 2 || map[i][j+2].getDescription() == 4)) ||
                    ((j == lastj) && (i - lasti == 4) && (map[i-2][j].getDescription() == 2 || map[i-2][j].getDescription() == 4)) ||
                    ((j == lastj) && (i - lasti == -4) && (map[i+2][j].getDescription() == 2 || map[i+2][j].getDescription() == 4))){
                        haveFroginMiddle = 1; // there is a frog
                    }
                }
                //Move the selected frog to the destination, and then eliminate the frog in the middle
                if(e.getSource() == map[i][j].getButton()){
                    if((note == 1) && (haveFroginMiddle == 1) && (map[i][j].getDescription() != 2) && (map[i][j].getDescription() != 4)){
                        // move the frog, task 3
                        map[lasti][lastj].moveTo(map[i][j]);
                        //Jumping diagonally, set the middle frog disappear, task 4
                        if((i - lasti == 2) && (j - lastj == 2) && (map[i-1][j-1].getDescription() == 2 || map[i-1][j-1].getDescription() == 4)){
                            music.playJump();
                            map[i-1][j-1].setButtonIcon(0);
                        }
                        if((i - lasti == -2) && (j - lastj == 2) && (map[i+1][j-1].getDescription() == 2 || map[i+1][j-1].getDescription() == 4)){
                            music.playJump();
                            map[i+1][j-1].setButtonIcon(0);
                        }
                        if((j - lastj == -2) && (i - lasti == 2) && (map[i-1][j+1].getDescription() == 2 || map[i-1][j+1].getDescription() == 4)){
                            music.playJump();
                            map[i-1][j+1].setButtonIcon(0);
                        }
                        if((j - lastj == -2) && (i - lasti == -2) && (map[i+1][j+1].getDescription() == 2 || map[i+1][j+1].getDescription() == 4)){
                            music.playJump();
                            map[i+1][j+1].setButtonIcon(0);
                        }
                        //Jumping horizontally or vertically
                        if((i == lasti) && (j - lastj == 4) && (map[i][j-2].getDescription() == 2 || map[i][j-2].getDescription() == 4)){
                            music.playJump();
                            map[i][j-2].setButtonIcon(0);
                        }
                        if((i == lasti) && (j - lastj == -4) && (map[i][j+2].getDescription() == 2 || map[i][j+2].getDescription() == 4)){
                            music.playJump();
                            map[i][j+2].setButtonIcon(0);
                        }
                        if((j == lastj) && (i - lasti == 4) && (map[i-2][j].getDescription() == 2 || map[i-2][j].getDescription() == 4)){
                            music.playJump();
                            map[i-2][j].setButtonIcon(0);
                        }
                        if((j == lastj) && (i - lasti == -4) && (map[i+2][j].getDescription() == 2 || map[i+2][j].getDescription() == 4)){
                            music.playJump();
                            map[i+2][j].setButtonIcon(0);
                        }
                    }
                }
                
                //Select the clicked green frog, and then highlight it
                if(e.getSource() == map[i][j].getButton() && map[i][j].getDescription() == 2){
                    //Remove the last highlighting
                    if(note == 1){  
                        map[lasti][lastj].setButtonIcon(map[lasti][lastj].getDescription() - 2);
                        note = 0;
                    }
                    music.playFrog();
                    map[i][j].setButtonIcon(2);
                    this.lasti = i;
                    this.lastj = j;
                    note = 1;
                    haveFroginMiddle = 0;
                }
                //Select the clicked red frog, and then highlight it
                if(e.getSource() == map[i][j].getButton() && map[i][j].getDescription() == 4){
                    //Remove the last highlighting
                    if(note == 1){  
                        map[lasti][lastj].setButtonIcon(map[lasti][lastj].getDescription() - 2);
                        note = 0;
                    }
                    music.playFrog();
                    map[i][j].setButtonIcon(4);
                    this.lasti = i;
                    this.lastj = j;
                    note = 1;      
                    haveFroginMiddle = 0;
                }
            }
        }

        //To see whether the player wins the game
        winGame();
        //To see wheter the player has already lost the game
        if(win == false){
            loseGame();
        }
    
        //Function of the top four buttons
        if(e.getSource() == giveUp){ // button "Give Up?"
            music.playClicked();
            
            int optionSelected = JOptionPane.showConfirmDialog(null, "Are you sure to give up and back to the menu?", 
            "REMINDER", JOptionPane.YES_NO_OPTION);
            //Choose "Yes", then back to menu
            if(optionSelected == JOptionPane.YES_OPTION){
                music.playClicked();
                frame.dispose();
                Menu menu = new Menu();
            }
            //Choose "No", then nothing will happen
            if(optionSelected == JOptionPane.NO_OPTION){
                music.playClicked();
            }
        }
        //Button "Try Again?"
        if(e.getSource() == tryAgain){
            music.playClicked();
            frame.dispose();
            Play play = new Play(currentLevel);
        }
        //Button "Help"
        if(e.getSource() == help){
            music.playClicked();
            int optionSelected = JOptionPane.showConfirmDialog(null, "Are you sure to look tips?", 
            "REMINDER", JOptionPane.YES_NO_OPTION);
            if(optionSelected == JOptionPane.YES_OPTION){
                music.playClicked();
                if(currentLevel == 1){
                    JOptionPane.showMessageDialog(null, 
                    "Tips:\n" + "(1,1)[red] → (3,3) → (5,5)\n" +"\n" 
                    + "(x,y): It is the coordinates of the frog, x means rows, y means column.\n"
                    + "[color]: It means the color of the selected frog.\n", 
                    "TIPS", JOptionPane.PLAIN_MESSAGE);
                }
                if(currentLevel == 2){
                    JOptionPane.showMessageDialog(null, 
                    "Tips:\n" + "(5,5)[green] → (1,5) → (1,1) → (5,1) → (3,3)\n" + "(5,3)[red] → (3,1)\n"
                    +"\n" + "(x,y): It is the coordinates of the frog, x means rows, y means column.\n"
                    + "[color]: It means the color of the selected frog.\n", 
                    "TIPS", JOptionPane.PLAIN_MESSAGE);
                }
                if(currentLevel == 3){
                    JOptionPane.showMessageDialog(null, 
                    "Tips:\n" + "(2,2)[green] → (4,4)\n" + "(5,5)[red] → (3,3) → (1,5) → (1,1) → (5,1) → (3,3)\n"
                    +"\n" + "(x,y): It is the coordinates of the frog, x means rows, y means column.\n"
                    + "[color]: It means the color of the selected frog.\n", 
                    "TIPS", JOptionPane.PLAIN_MESSAGE);
                }
            }
            if(optionSelected == JOptionPane.NO_OPTION){
                music.playClicked();
            }
        }
        //Button "Setting"
        if(e.getSource() == setLevel){
            music.playClicked();
            
            int levelChosen = 0;
            String levelChange = (String) JOptionPane.showInputDialog(null, 
            "You can change Level: (current level is " + currentLevel + ")\n", 
            "Setting", JOptionPane.PLAIN_MESSAGE, null, levelOptions, levelOptions[0]);
            //Choose the level
            if(levelChange.equals("Level 1")){
                levelChosen = 1;
            }
            else if(levelChange.equals("Level 2")){
                levelChosen = 2;
            }
            else if(levelChange.equals("Level 3")){
                levelChosen = 3;
            }
            //Jump into the level, if the level remains the same, the frame remains the same
            if(levelChosen == currentLevel){ // do nothing
            }
            else{
                frame.dispose();
                currentLevel = levelChosen;
                Play play = new Play(currentLevel); // jump into the chosen level
            }
        }
    }
    
    /**
     * mouseEntered method
     * This method used to react when the mouse touches the buttons
     * a specific sound will be played
     * @param e the event indicating that the button has been touched by mouse
     */
    public void mouseEntered(MouseEvent e){
        //Touches the buttons
        if((e.getSource() == tryAgain) || (e.getSource() == setLevel) 
        || (e.getSource() == help) || (e.getSource() == giveUp)){
            music.playBeforeClick();
        }
        
        //Touches the pats or frogs on the map
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                if((e.getSource() == map[i][j].getButton()) && ((map[i][j].getDescription() == 1) || (map[i][j].getDescription() == 2) || (map[i][j].getDescription() == 4))){
                    music.playBeforeClick();
                }
            }
        }
    }
    
    /**
     * mouseClicked method
     * is an abstract funtion
     */
    public void mouseClicked(MouseEvent e){}
    
    /**
     * mouseExited method
     * is an abstract funtion
     */
    public void mouseExited(MouseEvent e){}
    
    /**
     * mousePressed method
     * is an abstract funtion
     */
    public void mousePressed(MouseEvent e){}
    
    /**
     * mouseReleased method
     * is an abstract funtion
     */
    public void mouseReleased(MouseEvent e){}
    
}
