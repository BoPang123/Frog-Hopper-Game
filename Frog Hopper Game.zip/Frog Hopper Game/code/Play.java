import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * Play Class
 * used to provides the location of frogs of each level
 * Play also holds the level of the game
 * @author
 */
public class Play
{
    private int level;
    
    /**
     * Play constructor
     * This method returns the map containing frogs which can be played
     * @param level level of the game, indicating where frogs should display
     */
    public Play(int level){
        this.level = level;
        
        //The map of level 1
        if(level == 1){
            Board game = new Board();
            game.map[0][0].setButtonIcon(3);
            game.map[1][1].setButtonIcon(1);
            game.map[3][3].setButtonIcon(1);
            game.setLevel(level); // pass the level parameter to the Broad class
        }
        
        //The map of level 2
        if(level == 2){
            Board game = new Board();
            game.map[0][2].setButtonIcon(1);
            game.map[2][0].setButtonIcon(1);
            game.map[2][4].setButtonIcon(1);
            game.map[3][1].setButtonIcon(1);
            game.map[4][2].setButtonIcon(3);
            game.map[4][4].setButtonIcon(1);
            game.setLevel(level); // pass the level parameter to the Broad class
        }
        
        //The map of level 3
        if(level == 3){
            Board game = new Board();
            game.map[0][2].setButtonIcon(1);
            game.map[1][1].setButtonIcon(1);
            game.map[1][3].setButtonIcon(1);
            game.map[2][0].setButtonIcon(1);
            game.map[2][2].setButtonIcon(1);
            game.map[3][1].setButtonIcon(1);
            game.map[4][4].setButtonIcon(3);
            game.setLevel(level); // pass the level parameter to the Broad class
        }
    }
    
    /**
     * getLevel method
     * @return int which is the current level from Play
     */
    public int getLevel(){
        return level;
    }
    
    /**
     * setLevel method
     * used to change level of game
     * @param level not negative integer value from 1 to 3
     */
    public void setLevel(int level){
        this.level = level;
    }

}
