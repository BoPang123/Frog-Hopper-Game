import java.awt.*;
import java.applet.*;
import javax.swing.*;
import java.awt.event.*;
/**
 * ChooseLevel Class
 * is used to choose level for the player at the beginning of the game
 * There are four clickable buttons for the player to choose
 * 'level1' button, moving to the first level of the game
 * 'level2' button, moving to the second level of the game
 * 'level3' button, moving to the final level of the game
 * 'backToMenu' button, backing to the menu window
 * @author
 */
public class ChooseLevel implements ActionListener, MouseListener
{
    private JFrame frame;
    private JButton level1;
    private JButton level2;
    private JButton level3;
    private JButton backToMenu;
    private JLabel background;
    private JLabel textChooseLevel;
    private ImageIcon backgroundImage;
    private Music music = new Music();

    /**
     * ChooseLevel constructor
     * This method returns frame containing
     * level1, level2, level3, and backToMenu buttons
     */
    public ChooseLevel()
    {
        //Set the frame ready
        frame = new JFrame();
        frame.setTitle("Hoppers!");
        frame.setSize(750, 750);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Set the image as background
        backgroundImage = new ImageIcon("C:\\Users\\Desktop\\Frog Hopper Game\\resource\\cover.png");
        background = new JLabel(backgroundImage);
        background.setSize(750, 750);
        frame.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
        JPanel panel = (JPanel) frame.getContentPane();
        
        //Initialize basic panel and layout of the ChooseLevel window
        BoxLayout layout= new BoxLayout(panel, BoxLayout.X_AXIS);
        panel.setLayout(layout);
        
        //Initialize the button panel and layout of the ChooseLevel
        JPanel mainPanel = new JPanel();
        BoxLayout levelLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
        mainPanel.setLayout(levelLayout);
        
        //Initialize level-choosing buttons
        level1 = new JButton("Level 1");
        level1.addActionListener(this);
        level1.addMouseListener(this);
        level2 = new JButton("Level 2");
        level2.addActionListener(this);
        level2.addMouseListener(this);
        level3 = new JButton("Level 3");
        level3.addActionListener(this);
        level3.addMouseListener(this);
        backToMenu = new JButton("Back to Menu");
        backToMenu.addActionListener(this);
        backToMenu.addMouseListener(this);
        
        //Add buttons to the panel in the proper location
        mainPanel.add(Box.createGlue());
        mainPanel.add(Box.createGlue());
        mainPanel.add(level1);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(level2);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(level3);
        mainPanel.add(Box.createVerticalStrut(100));
        mainPanel.add(backToMenu);
        mainPanel.add(Box.createGlue());
        
        //Set the location of the panel in the whole window
        panel.add(Box.createGlue());
        panel.add(mainPanel);
        panel.add(Box.createHorizontalStrut(20));
        
        //Make this window visible
        panel.setOpaque(false);
        mainPanel.setOpaque(false);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    /**
     * actionPerformed method
     * This method used to react after the player clicked
     * 'level1' button, displaying the map of the first level
     * 'level2' button, displaying the map of the second level
     * 'level3' button, displaying the map of the final level
     * 'backToMenu' button, backing to the menu window
     * A specific sound is also provided as response
     */
    public void actionPerformed(ActionEvent e){
        //Player choose the level and then start to play
        if(e.getSource() == level1){
            music.playClicked();
            frame.dispose();
            Play play = new Play(1);
        }
        if(e.getSource() == level2){
            music.playClicked();
            frame.dispose();
            Play play = new Play(2);
        }
        if(e.getSource() == level3){
            music.playClicked();
            frame.dispose();
            Play play = new Play(3);
        }
        //Player choose to back to the menu window
        if(e.getSource() == backToMenu){
            music.playClicked();
            frame.dispose();
            Menu menu = new Menu();
        }
    }
    
    /**
     * mouseEntered method
     * This method used to react when the mouse touches the buttons
     * a specific sound will be played
     * @param e the event indicating that the button has been touched by mouse
     */
    public void mouseEntered(MouseEvent e){
        if((e.getSource() == level1) || (e.getSource() == level2) 
        || (e.getSource() == level3) || (e.getSource() == backToMenu)){
            music.playBeforeClick();
        }
    }
    
    /**
     * mouseClicked method
     * is an abstract funtion
     */
    public void mouseClicked(MouseEvent e){}
    
    /**
     * mouseExited method
     * is an abstract funtion
     */
    public void mouseExited(MouseEvent e){}
    
    /**
     * mousePressed method
     * is an abstract funtion
     */
    public void mousePressed(MouseEvent e){}
    
    /**
     * mouseReleased method
     * is an abstract funtion
     */
    public void mouseReleased(MouseEvent e){}
}
